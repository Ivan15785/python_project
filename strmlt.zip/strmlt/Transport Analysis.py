#!/usr/bin/env python
# coding: utf-8

# # Анализ Московского Метрополитена

# В ходе данного проекта, основной целью которого было демонстрация моих навыков работы с инструментами анализа данных, я использовал различные методы и техники для исследования и визуализации данных. Проект не ограничивался простым выполнением задачи анализа, а скорее фокусировался на моей способности применять эти инструменты и подходы для получения полезной информации и делать осмысленные выводы.
# 
# В ходе работы над проектом я активно использовал популярные библиотеки и инструменты для анализа данных, такие как Pandas, NumPy, Matplotlib и Seaborn. С помощью Pandas я выполнял обработку и очистку данных, применял различные операции и агрегирование для получения нужной информации. Затем, с использованием Matplotlib и Seaborn, я создавал визуализации, такие как графики, диаграммы и дашборды, чтобы наглядно представить полученные результаты и делать осмысленные выводы.
# 
# В целом, данный проект позволил мне продемонстрировать мою способность использовать инструменты для анализа данных и эффективно работать с ними. Полученные результаты и визуализации подчеркнули мою готовность и умение использовать эти инструменты для извлечения ценной информации из данных и принятия обоснованных решений на основе аналитических выводов.

# In[1]:


import numpy as np
import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt
import matplotlib.ticker as ticker
import geopandas as gpd
import selenium
from selenium.webdriver import Chrome
from selenium.webdriver.common.keys import Keys 
from selenium.webdriver.support import expected_conditions as EC
from selenium.common.exceptions import NoSuchElementException
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.common.exceptions import TimeoutException
from bs4 import BeautifulSoup
from tqdm import tqdm
import requests
import time
import re
import wget
from zipfile import ZipFile


# # Парсинг данных для дальнейшей визуализации

# In[2]:


url = 'https://ru.wikipedia.org/wiki/%D0%A1%D0%BF%D0%B8%D1%81%D0%BE%D0%BA_%D1%81%D1%82%D0%B0%D0%BD%D1%86%D0%B8%D0%B9_%D0%9C%D0%BE%D1%81%D0%BA%D0%BE%D0%B2%D1%81%D0%BA%D0%BE%D0%B3%D0%BE_%D0%BC%D0%B5%D1%82%D1%80%D0%BE%D0%BF%D0%BE%D0%BB%D0%B8%D1%82%D0%B5%D0%BD%D0%B0'
driver = Chrome()
driver.get(url)
stations = driver.find_elements('xpath','//table[@class="standard sortable jquery-tablesorter"][1]/tbody/tr/td[2]')
opening_date = driver.find_elements('xpath','//table[@class="standard sortable jquery-tablesorter"][1]/tbody/tr/td[3]')
#interchanges = driver.find_elements('xpath','//table[@class="standard sortable jquery-tablesorter"][1]/tbody/tr/td[4]')
depth = driver.find_elements('xpath','//table[@class="standard sortable jquery-tablesorter"][1]/tbody/tr/td[5]')
types = driver.find_elements('xpath','//table[@class="standard sortable jquery-tablesorter"][1]/tbody/tr/td[6]')
coord = driver.find_elements('xpath','//table[@class="standard sortable jquery-tablesorter"][1]/tbody/tr/td[7]')


# Создаем первый датафрейм, который будем использовать в целях удобства хранения данных, которые возможно позже пригодятся если у меня возникнет идея для задачи для машинного обучения

# In[3]:


df_moscow = pd.DataFrame(columns = ['Station', 'Opening_date',  'Depth', 'Type', 'Coordinates'])


# In[4]:


for i in range(len(stations)):
    df_moscow = df_moscow.append({'Station' : stations[i].text, 
                                  'Opening_date' : opening_date[i].text, 
                                  'Depth' : depth[i].text,
                                  'Type' : types[i].text,
                                  'Coordinates' : coord[i].text
                                 }, ignore_index = True)


# In[5]:


def coord_change_system(coord):

    # Извлечение цифр с помощью регулярного выражения
    numbers = re.findall(r'\d+', coord)

    # Присвоение каждой цифре своей переменной
    var1 = int(numbers[0])
    var2 = int(numbers[1])
    var3 = int(numbers[2])
    var4 = int(numbers[3])
    var5 = int(numbers[4])
    var6 = int(numbers[5])
    coord1 = var1 + var2/60 + var3/3600
    coord2 = var4 + var5/60 + var6/3600
    coord1 = float('{:.6f}'.format(coord1))
    coord2 = float('{:.6f}'.format(coord2))
    if 'ю' in coord:
        coord1 = -coord1
    if 'з' in coord:
        coord2 = -coord2
    
    return str(coord1) + ',' + str(coord2)


# In[6]:


df_moscow['Station'] = df_moscow['Station'].str.split('\n').str[0]
df_moscow['Type'] = df_moscow['Type'].str.replace('\n',' ')
df_moscow['Coordinates'] = df_moscow['Coordinates'].apply(coord_change_system)


# In[7]:


df_moscow


# In[8]:


points = df_moscow['Coordinates'].tolist()


# In[9]:


points_upd = []
for i in range(len(points)):
    lat, lon = points[i].split(',')
    pair = (float(lat), float(lon))
    points_upd.append(pair)


# ## Визуализация

# Используем функционал matplotlib и geopandas, чтобы получить наглядную карту москвы со всеми отмеченными станциями метро

# In[10]:


adm_moscow = gpd.read_file("http://gis-lab.info/data/mos-adm/mo.geojson")

fig, ax = plt.subplots(figsize=(15, 15))  
adm_moscow.plot(ax=ax, color="blue", edgecolor="black")

for point in points_upd:
    x, y = float(point[1]), float(point[0])
    ax.scatter(x, y, color="red", marker="o", s = 10)

plt.show()


# # Парсинг данных для дальнейшего анализа

# In[11]:


#НЕ ЗАПУСКАТЬ!!!
url2 = 'https://data.mos.ru/opendata/62743?pageNumber=1&versionNumber=1&releaseNumber=17'
driver2 = Chrome()
driver2.get(url2)

wait = WebDriverWait(driver, 10)

all_data = []  

# Парсинг первой страницы
elements = driver.find_elements('xpath', '/html/body/div[2]/div/div[7]/section[1]/div[3]/div[1]/div/table[1]/tbody/tr')
for element in elements:
    cells = element.find_elements('tag name', 'td')
    row_data = [cell.get_attribute('textContent').strip() for cell in cells]
    all_data.append(row_data)  
    print(row_data)

current_page_number = 1

while True:
    current_page_number += 1
    next_page_url = f'https://data.mos.ru/opendata/62743?pageNumber={current_page_number}&versionNumber=1&releaseNumber=17'
    driver.get(next_page_url)  #Используем f-строки для навигации по страницам
    time.sleep(0.5)  # Задержка позволяет странице прогрузится

    # Условие для выхода из парсинга
    if 'No data found' in driver.page_source or current_page_number > 252:
        break

    elements = driver.find_elements('xpath', '/html/body/div[2]/div/div[7]/section[1]/div[3]/div[1]/div/table[1]/tbody/tr')
    for element in elements:
        cells = element.find_elements('tag name', 'td')
        row_data = [cell.get_attribute('textContent').strip() for cell in cells]
        all_data.append(row_data)  
        print(row_data)

for data in all_data:
    print(data)


# In[12]:


all_data


# In[13]:


for item in reversed(all_data):
    item[0] = item[0].split()[1] 
print(all_data)


# In[14]:


for item in all_data:
    del item[-1]


# In[15]:


all_data


# In[16]:


df_moscow_flow = pd.DataFrame(columns = ['Station', 'Line',  'Year', 'Quarter', 'Entries', 'Exits'])


# In[17]:


for i in range(len(all_data)):
    df_moscow_flow = df_moscow_flow.append({'Station' : all_data[i][0], 
                                  'Line' : all_data[i][1], 
                                  'Year' : all_data[i][2],
                                  'Quarter' : all_data[i][3],
                                  'Entries' : all_data[i][4],
                                  'Exits' : all_data[i][5]
                                 }, ignore_index = True)


# In[18]:


df_moscow_flow


# In[19]:


quarter_mapping = {'I квартал': 1, 'II квартал': 2, 'III квартал': 3, 'IV квартал': 4}
df_moscow_flow['Quarter'] = df_moscow_flow['Quarter'].replace(quarter_mapping)
df_moscow_flow['Year'] = pd.to_numeric(df_moscow_flow['Year'])
df_moscow_flow['Entries'] = pd.to_numeric(df_moscow_flow['Entries'])
df_moscow_flow['Exits'] = pd.to_numeric(df_moscow_flow['Exits'])
df_moscow_flow


# In[20]:


passenger_sum_entries_by_year = df_moscow_flow.groupby(['Year', 'Quarter'])['Entries'].sum().reset_index()
sns.barplot(data=passenger_sum_entries_by_year, x='Year', y='Entries', hue='Quarter')
plt.xlabel('Year')
plt.ylabel('Total Passengers')
plt.title('Total Passengers by Year')
ax = plt.gca()
ax.yaxis.set_major_formatter(ticker.StrMethodFormatter('{x:,.0f}'))
plt.show()


# In[21]:


passenger_sum_exits_by_year = df_moscow_flow.groupby(['Year', 'Quarter'])['Exits'].sum().reset_index()
sns.barplot(data=passenger_sum_exits_by_year, x='Year', y='Exits', hue='Quarter')
plt.xlabel('Year')
plt.ylabel('Total Passengers')
plt.title('Total Passengers by Year')
ax = plt.gca()
ax.yaxis.set_major_formatter(ticker.StrMethodFormatter('{x:,.0f}'))
plt.show()


# Изучение пассажиропотока московского метрополитена с помощью барчарта позволяет выделить важную тенденцию: пассажиропоток увеличивался как по годам, так и поквартально. В 2023 этот рост связан с открытием Большой кольцевой линии (БКЛ), которая стала значимым элементом московской инфраструктуры.
# 
# При анализе барчарта можно заметить, что каждый год количество пассажиров постоянно возрастал. Это свидетельствует о постоянном росте популярности данной транспортной системы среди жителей и посетителей города. Открытие БКЛ стало важным моментом, который способствовал увеличению пассажиропотока.
# 
# Таким образом, анализ барчарта подтверждает, что пассажиропоток рос как в годовом, так и в поквартальном аспекте. Эти результаты подчеркивают значимость и важность Московского метрополитена в транспортной инфраструктуре города и его растущую популярность среди пассажиров.
