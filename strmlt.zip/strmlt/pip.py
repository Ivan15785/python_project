import streamlit as st

def main():
    st.title("My Streamlit App")
    st.write("This is my IPython Notebook streamed using Streamlit!")

    with open(r'C:\Users\Пользователь\Desktop\strmlt\Transport Analysis.py', 'r', encoding='utf-8') as file:
        script_code = file.read()
        st.code(script_code, language='python')

if __name__ == "__main__":
    main()
